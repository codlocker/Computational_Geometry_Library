#!/bin/bash
echo "Bash version ${BASH_VERSION}..."
g++ ../main.cpp -o ../bin/HullGenerator
for ((i=30;i<=100;i+=10))
do 
	echo -n "20">"sampleInput$i.txt"
	for((j=0;j<20;j++))
	do
		echo "">>"sampleInput$i.txt"
		echo -n "$RANDOM $RANDOM">>"sampleInput$i.txt"  
	done
	START=$(date +%s.%N)
	../bin/HullGenerator "sampleInput$i.txt"
	END=$(date +%s.%N)
	DIFF=$(echo "$END - $START" | bc)
	echo "Diff=$DIFF"
done